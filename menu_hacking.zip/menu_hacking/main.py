import pygame
import subprocess
import sys
from PyQt5 import uic
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow


class WindowMain(QMainWindow):

    options = [
          {
          'title':'Fuerza Bruta',
          'logo':'apps_preview/fuerza_bruta.png',
          'path':'apps/fuerza_bruta/Main.py'
          },
          {
          'title':'HAPHACK',
          'logo':'apps_preview/haphack.png',
          'path':'apps/HAPHACK/App.py'
          },
          {
          'title':'Payload',
          'logo':'apps_preview/payload.png',
          'path':'apps/Payload/menuComandos.py'
          },
          {
          'title':'Phishing',
          'logo':'apps_preview/phishing.png',
          'path':'apps/phishing/main.py'
          },
          {
          'title':'Spam Socialnet',
          'logo':'apps_preview/spam_socialnet.png',
          'path':'apps/spam_socialnet/main.py'
          }
          ]

    def __init__(self):
        QMainWindow.__init__(self)
        uic.loadUi('gui/main.ui', self)

        # Color del backgroud de la ventana y el icono
        self.setStyleSheet('background-color: rgba(0, 0, 0, 1);')
        self.setWindowIcon(QIcon('gui/img/favicon.ico'))

        # Agregar el background de borde metálico, y hacer que el
        # background se estire hasta rellenar el tamaño de su contenedor
        self.LBackground.setPixmap(QPixmap('gui/img/widesliderbg.png'))
        self.LBackground.setScaledContents(True)

        # Agregar el background a los botones de desplazamiento
        self.RightButton.setStyleSheet(
            'background-image: url(gui/img/right.png);')
        self.LeftButton.setStyleSheet(
            'background-image: url(gui/img/left.png);')

        # Agregar background y estilos a los botones que inician
        # las apps

        css_start_buttons = """
        background-image: url(gui/img/start.png);
        background-position: top right;
        text-align: center;
        padding: 0 30px 3px 16px;
        font-weight: bold;
        font-size: 13px;
        border: none;
        """
        css_start_buttons_aux = """
        background-image: url(gui/img/start_aux.png);
        """

        self.StartButton1.setStyleSheet(css_start_buttons)
        self.StartButton2.setStyleSheet(css_start_buttons)
        self.StartButton3.setStyleSheet(css_start_buttons)

        self.StartButton1Aux.setStyleSheet(css_start_buttons_aux)
        self.StartButton2Aux.setStyleSheet(css_start_buttons_aux)
        self.StartButton3Aux.setStyleSheet(css_start_buttons_aux)

        # Eventos de los botones de dezplazamiento
        self.RightButton.clicked.connect(self.move_right)
        self.LeftButton.clicked.connect(self.move_left)

        # Eventos de los botones que inician las apps
        self.StartButton1.clicked.connect(self.run_app)
        self.StartButton2.clicked.connect(self.run_app)
        self.StartButton3.clicked.connect(self.run_app)

        # Eventos para reproducir sonido con el click
        self.RightButton.clicked.connect(self.metalic_click_sound)
        self.LeftButton.clicked.connect(self.metalic_click_sound)
        self.StartButton1.clicked.connect(self.start_sound)
        self.StartButton2.clicked.connect(self.start_sound)
        self.StartButton3.clicked.connect(self.start_sound)

        # Iniciamos las opciones por default
        self.refresh_options()

    def metalic_click_sound(self):
        pygame.init()
        pygame.mixer.music.load('gui/sounds/metalic_click.mp3')
        pygame.mixer.music.play()
        return

    def start_sound(self):
        pygame.init()
        pygame.mixer.music.load('gui/sounds/start.mp3')
        pygame.mixer.music.play()
        return

    def move_left(self):
        aux = self.options[0]
        for i in range(len(self.options) - 1):
            self.options[i] = self.options[i + 1]
        self.options[-1] = aux

        self.refresh_options()
        return

    def move_right(self):
        aux = self.options[-1]
        for i in reversed(range(1, len(self.options))):
            self.options[i] = self.options[i - 1]
        self.options[0] = aux

        self.refresh_options()
        return

    def run_app(self):
        if self.sender().objectName() == 'StartButton1':
            path = self.options[0]['path']
        elif self.sender().objectName() == 'StartButton2':
            path = self.options[1]['path']
        elif self.sender().objectName() == 'StartButton3':
            path = self.options[2]['path']

        subprocess.Popen('python ' + path,
                         creationflags=subprocess.CREATE_NEW_CONSOLE)
        return

    def refresh_options(self):
        self.LOption1.setPixmap(QPixmap(self.options[0]['logo']))
        self.LOption2.setPixmap(QPixmap(self.options[1]['logo']))
        self.LOption3.setPixmap(QPixmap(self.options[2]['logo']))

        self.StartButton1.setText(self.options[0]['title'])
        self.StartButton2.setText(self.options[1]['title'])
        self.StartButton3.setText(self.options[2]['title'])

        return


app = QApplication(sys.argv)
_window = WindowMain()
_window.show()
app.exec_()
