import os
import time

os.system('pause')
time.sleep(3)
os.system('ngrok http 3000')
