#===========================
#              Display option                  #
def showDisplay(mode,string):
	if(mode == 0):
		print string
	else:
		pass
#===========================
def setDisplay(mode):
	displayMode = mode

#global displayMode
#displayMode = 0
#global displayMode
#global displayMode
#===========================
