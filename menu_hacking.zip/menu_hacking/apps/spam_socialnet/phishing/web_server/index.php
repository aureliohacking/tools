<?php
if(!empty($_POST['sq'])){
  echo $_POST['sq'];
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>BLA BLA</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php echo 'Holis'; ?>
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" accept-charset="utf-8">
		<input type="text" name="sq" value="sss">
		<button type="submit">Enviar</button>
	</form>
</body>
</html>